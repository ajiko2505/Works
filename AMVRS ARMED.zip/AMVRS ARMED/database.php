<?php
$serverName = "localhost";
$username = "root";
$password = "";
$dbname = "amvrss";
$dbh = mysqli_connect($serverName, $username, $password, $dbname);